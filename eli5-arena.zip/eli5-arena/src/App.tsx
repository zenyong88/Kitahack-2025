import { Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import LandingPage from './pages/LandingPage';
import YourQuestionsPage from './pages/YourQuestionsPage';
import YourAnswersPage from './pages/YourAnswersPage';
import QuestionPage from './pages/QuestionPage';
import AskQuestionPage from './pages/AskQuestionPage';
import LeaderboardPage from './pages/LeaderboardPage';
import ExplorePage from './pages/ExplorePage';
import ExploreTopicsPage from './pages/ExploreTopicsPage';
import ExploreTopicDetailPage from './pages/ExploreTopicDetailPage';
import NotFoundPage from './pages/NotFoundPage'; // Optional: for 404
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import AuthProvider from './contexts/AuthContext'; // Placeholder for Auth Context
import { useAuth } from './contexts/AuthContext';

// Protected Route component
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  if (!user) {
    return <Navigate to="/login" />;
  }
  return <>{children}</>;
};

function App() {
  return (
    <AuthProvider> {/* Wrap with Auth Context Provider */}
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<LandingPage />} />
          <Route path="your-questions" element={<YourQuestionsPage />} />
          <Route path="your-answers" element={<YourAnswersPage />} />
          <Route path="question/:id" element={<QuestionPage />} /> {/* Answering Type */}
          <Route 
            path="ask" 
            element={
              <ProtectedRoute>
                <AskQuestionPage />
              </ProtectedRoute>
            } 
          />
          <Route path="leaderboard" element={<LeaderboardPage />} />
          <Route path="explore" element={<ExplorePage />} />
          <Route path="explore/topics" element={<ExploreTopicsPage />} />
          <Route path="explore/topic/:topicId" element={<ExploreTopicDetailPage />} />
          <Route path="*" element={<NotFoundPage />} /> {/* Catch-all for 404 */}
        </Route>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
      </Routes>
    </AuthProvider>
  );
}

export default App;
