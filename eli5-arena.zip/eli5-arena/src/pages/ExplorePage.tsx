import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ExploreData, getExploreData } from '../utils/dataService';
import { useAuth } from '../contexts/AuthContext';

// Form Select Component
const FormSelect: React.FC<{
  label: string;
  id: string;
  options: string[];
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}> = ({ label, id, options, value, onChange }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-2">
      {label}
    </label>
    <select
      id={id}
      className="w-full p-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
      value={value}
      onChange={onChange}
    >
      <option value="">Select an option</option>
      {options.map(option => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  </div>
);

const ExplorePage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [selectedGrade, setSelectedGrade] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('');
  const [exploreData, setExploreData] = useState<ExploreData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is logged in
  useEffect(() => {
    if (!user) {
      navigate('/login', { state: { from: location } });
    }
  }, [user, navigate, location]);

  // Fetch explore data
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const data = await getExploreData();
        setExploreData(data);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching explore data:', err);
        setError('Failed to load explore data. Please try again later.');
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Extract available grades and subjects from explore data
  const gradeSubjectKeys = exploreData 
    ? Object.keys(exploreData.topicsByGradeSubject) 
    : [];
  
  // Extract and sort grades by number
  const grades = [...new Set(gradeSubjectKeys.map(key => key.split('-')[0]))]
    .sort((a, b) => {
      // Extract the numeric part from strings like "Grade 7", "Grade 10", etc.
      const numA = parseInt(a.match(/\d+/)?.[0] || '0');
      const numB = parseInt(b.match(/\d+/)?.[0] || '0');
      return numA - numB;
    });
  
  const subjects = [...new Set(gradeSubjectKeys.map(key => key.split('-')[1]))];
 
  // Handle role selection
  const handleRoleSelect = (role: 'Educator' | 'Student') => {
    if (!selectedGrade || !selectedSubject) {
      alert('Please select both a grade and subject first');
      return;
    }
    
    // Navigate to the topics page with the selected parameters
    navigate('/explore/topics', {
      state: {
        grade: selectedGrade,
        subject: selectedSubject,
        role
      }
    });
  };

  if (loading) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-600 text-lg">Loading explore data...</p>
        {/* Optional: Add a spinner here */}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-10">
        <p className="text-red-600 text-lg">{error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold text-center text-gray-800">Explore Mode</h1>

      <div className="max-w-2xl mx-auto">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold mb-6 text-center text-gray-700">Select Your Preferences</h2>

          {/* Grade/Subject Selection Box */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <FormSelect
              label="Select Grade Level"
              id="gradeExplore"
              options={grades}
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
            />
            <FormSelect
              label="Select Subject Area"
              id="subjectExplore"
              options={subjects}
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
            />
          </div>

          {/* Role Selection */}
          <div className="mb-6 text-center">
            <h3 className="text-xl font-semibold mb-4 text-gray-700">Choose Your Role:</h3>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <button 
                onClick={() => handleRoleSelect('Educator')}
                disabled={!selectedGrade || !selectedSubject}
                className={`flex-1 py-4 px-6 rounded-lg text-white font-bold text-lg transition ${
                  selectedGrade && selectedSubject 
                    ? 'bg-purple-600 hover:bg-purple-700 cursor-pointer' 
                    : 'bg-purple-300 cursor-not-allowed'
                }`}
              >
                <div className="flex flex-col items-center">
                  <span className="text-xl mb-1">👨‍🏫</span>
                  <span>Contributing</span>
                  <span className="text-xs mt-1 opacity-80">I want to submit explanations</span>
                </div>
              </button>
              
              <button 
                onClick={() => handleRoleSelect('Student')}
                disabled={!selectedGrade || !selectedSubject}
                className={`flex-1 py-4 px-6 rounded-lg text-white font-bold text-lg transition ${
                  selectedGrade && selectedSubject 
                    ? 'bg-teal-600 hover:bg-teal-700 cursor-pointer' 
                    : 'bg-teal-300 cursor-not-allowed'
                }`}
              >
                <div className="flex flex-col items-center">
                  <span className="text-xl mb-1">📚</span>
                  <span>Learning</span>
                  <span className="text-xs mt-1 opacity-80">I want to learn from others</span>
                </div>
              </button>
            </div>
          </div>
          
          {/* Info Box */}
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-800">
            <p className="mb-2"><strong>Contributing:</strong> Share your expertise by writing simple explanations for concepts.</p>
            <p><strong>Learning:</strong> Read and vote on the best explanations from educators and experts.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExplorePage; 