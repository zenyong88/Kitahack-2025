import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Question, Topic, getQuestions, getTopics } from '../utils/dataService';

const YourQuestionsPage: React.FC = () => {
  const { user } = useAuth();
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Fetch questions and topics from API
        const [questionsData, topicsData] = await Promise.all([
          getQuestions(),
          getTopics()
        ]);
        
        setQuestions(questionsData);
        setTopics(topicsData);
        setLoading(false);
        setError(null);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load data. Please try again later.');
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Filter questions asked by the current user
  const userQuestions = questions.filter(q => q.author === user?.username);

  // Apply topic filter if selected
  const filteredQuestions = selectedTopic
    ? userQuestions.filter(q => q.topic === selectedTopic)
    : userQuestions;

  const handleTopicClick = (topicName: string) => {
    setSelectedTopic(selectedTopic === topicName ? null : topicName);
  };

  if (loading) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-600 text-lg">Loading your questions...</p>
        {/* Optional: Add a spinner here */}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-10">
        <p className="text-red-600 text-lg">{error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row gap-8">
      {/* Left Sidebar: Topics Filter */}
      <aside className="w-full md:w-1/4 lg:w-1/5">
         <div className="bg-white p-4 rounded-lg shadow sticky top-24"> {/* Added sticky positioning */}
          <h2 className="text-xl font-semibold mb-4 text-gray-700">Filter by Topic</h2>
          <ul className="space-y-2">
            {topics.map(topic => (
              <li key={topic.id}>
                <button
                  onClick={() => handleTopicClick(topic.name)}
                  className={`w-full text-left p-2 rounded transition duration-150 focus:outline-none ${
                    selectedTopic === topic.name
                      ? 'bg-blue-100 text-blue-900 font-medium'
                      : 'text-blue-700 hover:text-blue-900 hover:bg-blue-50'
                  }`}
                >
                  {topic.name}
                  <span className="ml-2 text-xs text-gray-500">
                    ({userQuestions.filter(q => q.topic === topic.name).length})
                  </span>
                </button>
              </li>
            ))}
          </ul>
          {selectedTopic && (
            <button
              onClick={() => setSelectedTopic(null)}
              className="mt-4 w-full text-sm text-blue-600 hover:text-blue-800"
            >
              Clear Filter
            </button>
          )}
        </div>
      </aside>

      {/* Main Content: User's Questions List */}
      <section className="w-full">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">Your Questions</h1>
          {selectedTopic && (
            <span className="text-sm text-gray-500">
              Filtered by: <span className="font-medium text-gray-700">{selectedTopic}</span>
            </span>
          )}
        </div>
        {filteredQuestions.length > 0 ? (
          <div className="space-y-5">
            {filteredQuestions.map(question => (
              // Question Card
              <div key={question.id} className="bg-white border border-gray-200 p-5 rounded-lg shadow hover:shadow-lg transition duration-200">
                <Link to={`/question/${question.id}`} className="block mb-2">
                  <h3 className="text-xl font-semibold text-blue-700 hover:text-blue-900 transition duration-150">{question.title}</h3>
                </Link>
                <div className="text-sm text-gray-500 mb-3">
                  <span>Topic: <span className="font-medium text-gray-700">{question.topic}</span></span>
                  {question.solved && (
                    <span className="ml-4 px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                      Solved
                    </span>
                  )}
                  {!question.solved && (
                    <span className="ml-4 px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                      Open
                    </span>
                  )}
                </div>
                {question.tags && (
                  <div className="flex flex-wrap gap-2">
                    {question.tags.map(tag => (
                      <span key={tag} className="inline-block bg-blue-100 text-blue-800 rounded-full px-3 py-1 text-xs font-semibold">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white border border-gray-200 p-6 rounded-lg shadow text-center">
            {selectedTopic ? (
              <>
                <p className="text-gray-600">You haven't asked any questions in this topic yet.</p>
                <button
                  onClick={() => setSelectedTopic(null)}
                  className="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded transition duration-300"
                >
                  Clear Filter
                </button>
              </>
            ) : (
              <>
                <p className="text-gray-600">You haven't asked any questions yet.</p>
                <Link
                  to="/ask"
                  className="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded transition duration-300"
                >
                  Ask One Now!
                </Link>
              </>
            )}
          </div>
        )}
      </section>
    </div>
  );
};

export default YourQuestionsPage; 