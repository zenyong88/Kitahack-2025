import React, { useState, useEffect } from 'react';
import { User, getUsers } from '../utils/dataService';

const LeaderboardPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'questions' | 'explore'>('questions');
  const [activeTab, setActiveTab] = useState<'score' | 'votes'>('score');
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const usersData = await getUsers();
        setUsers(usersData);
        setLoading(false);
        setError(null);
      } catch (err) {
        console.error('Error fetching users:', err);
        setError('Failed to load leaderboard data. Please try again later.');
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Sort users based on active category and tab
  const sortedUsers = [...users].sort((a, b) => {
    if (activeCategory === 'questions') {
      return activeTab === 'score' ? b.score - a.score : b.votes - a.votes;
    } else {
      return activeTab === 'score' ? b.exploreScore - a.exploreScore : b.exploreVotes - a.exploreVotes;
    }
  });

  if (loading) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-600 text-lg">Loading leaderboard...</p>
        {/* Optional: Add a spinner here */}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-10">
        <p className="text-red-600 text-lg">{error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Leaderboard</h1>
      
      {/* Category Tabs */}
      <div className="flex space-x-4 mb-6 border-b border-gray-200">
        <button
          onClick={() => setActiveCategory('questions')}
          className={`pb-2 px-4 ${
            activeCategory === 'questions'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Questions
        </button>
        <button
          onClick={() => setActiveCategory('explore')}
          className={`pb-2 px-4 ${
            activeCategory === 'explore'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Explore
        </button>
      </div>

      {/* Score/Votes Tabs */}
      <div className="flex space-x-4 mb-6 border-b border-gray-200">
        <button
          onClick={() => setActiveTab('score')}
          className={`pb-2 px-4 ${
            activeTab === 'score'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          {activeCategory === 'questions' ? 'Answer Success Rate' : 'Explore Success Rate'}
        </button>
        <button
          onClick={() => setActiveTab('votes')}
          className={`pb-2 px-4 ${
            activeTab === 'votes'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Most Votes
        </button>
      </div>

      {/* Leaderboard Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rank
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                User
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {activeTab === 'score' ? 'Success Rate' : 'Votes'}
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {activeCategory === 'questions' ? 'Questions' : 'Explore Questions'}
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {activeCategory === 'questions' ? 'Answers' : 'Explore Answers'}
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {activeCategory === 'questions' ? 'Best Answers' : 'Best Explore Answers'}
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedUsers.map((user, index) => (
              <tr key={user.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {index + 1}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <img
                        className="h-10 w-10 rounded-full"
                        src={user.avatar}
                        alt={user.username}
                      />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {user.username}
                      </div>
                      <div className="text-sm text-gray-500">
                        Joined {new Date(user.joinDate).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {activeTab === 'score' ? (
                    <span className="font-medium">
                      {activeCategory === 'questions' ? user.score : user.exploreScore}%
                    </span>
                  ) : (
                    activeCategory === 'questions' ? user.votes : user.exploreVotes
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {activeCategory === 'questions' ? user.questionsAsked : user.exploreAnswers}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {activeCategory === 'questions' ? user.answersGiven : user.exploreAnswers}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {activeCategory === 'questions' ? user.bestAnswers : user.exploreBestAnswers}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LeaderboardPage; 