import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Question, Topic, getQuestions, getTopics, saveQuestion } from '../utils/dataService';

// Basic Input Component (Example - can be moved to components folder)
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  id: string;
}
const FormInput: React.FC<InputProps> = ({ label, id, ...props }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
    <input
      id={id}
      {...props}
      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition duration-150"
    />
  </div>
);

// Basic Textarea Component (Example)
interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  id: string;
}
const FormTextarea: React.FC<TextareaProps> = ({ label, id, ...props }) => (
   <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
    <textarea
      id={id}
      {...props}
      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition duration-150"
    />
  </div>
);

// Basic Select Component
interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  id: string;
  options: Topic[];
}
const FormSelect: React.FC<SelectProps> = ({ label, id, options, ...props }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
    <select
      id={id}
      {...props}
      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition duration-150"
    >
      <option value="">Select {label}</option>
      {options.map(option => (
        <option key={option.id} value={option.name}>
          {option.name}
        </option>
      ))}
    </select>
  </div>
);

const AskQuestionPage: React.FC = () => {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [topic, setTopic] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [similarQuestions, setSimilarQuestions] = useState<Question[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const fetchData = async () => {
      try {
        setLoading(true);
        const [questionsData, topicsData] = await Promise.all([
          getQuestions(),
          getTopics()
        ]);
        
        setQuestions(questionsData);
        setTopics(topicsData);
        setLoading(false);
        setError(null);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load data. Please try again later.');
        setLoading(false);
      }
    };

    fetchData();
  }, [user, navigate]);

  useEffect(() => {
    if (searchTerm.trim().length > 2) { // Start searching after 3 characters
      console.log(`Searching for questions similar to: "${searchTerm}"`);
      // Simple title match
      const results = questions.filter(q =>
        q.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setSimilarQuestions(results.slice(0, 5)); // Limit results
    } else {
      setSimilarQuestions([]);
    }
  }, [searchTerm, questions]);

  const handleTagInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setTagInput(value);
    
    // If the last character is a comma, add the tag
    if (value.endsWith(',')) {
      const newTag = value.slice(0, -1).trim();
      if (newTag && !tags.includes(newTag)) {
        setTags([...tags, newTag]);
        setTagInput('');
      }
    }
  };

  const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault();
      if (!tags.includes(tagInput.trim())) {
        setTags([...tags, tagInput.trim()]);
        setTagInput('');
      }
    } else if (e.key === 'Backspace' && !tagInput && tags.length > 0) {
      setTags(tags.slice(0, -1));
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handlePostQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !topic) return;

    try {
      setSubmitting(true);

      // Create new question object
      const newQuestion = {
        title,
        body,
        topic,
        tags,
        author: user.username,
        solved: false
      };

      // Save to backend
      await saveQuestion(newQuestion);
      
      // Navigate to home page
      navigate('/');
    } catch (err) {
      console.error('Error posting question:', err);
      setError('Failed to post your question. Please try again.');
      setSubmitting(false);
    }
  };

  const handleVoteOnSimilar = (questionId: number) => {
    console.log(`User chose to view/vote on similar question ID: ${questionId}`);
    // Navigate to the existing question page instead of posting a new one
    navigate(`/question/${questionId}`);
  };

  if (loading) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-600 text-lg">Loading...</p>
        {/* Optional: Add a spinner here */}
      </div>
    );
  }

  if (error && !submitting) {
    return (
      <div className="text-center py-10">
        <p className="text-red-600 text-lg">{error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-lg shadow-lg">
      <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">Ask a New Question</h1>

      {/* Similar Questions Search */}
      <div className="mb-8 p-4 border border-blue-200 rounded-md bg-blue-50">
         <FormInput
            label="First, check if your question already exists:"
            id="searchSimilar"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Type keywords from your question..."
         />
        {similarQuestions.length > 0 && (
          <div className="mt-4 border-t border-blue-200 pt-4">
            <h3 className="text-md font-semibold mb-2 text-blue-800">Similar Questions Found:</h3>
            <ul className="space-y-2">
              {similarQuestions.map(q => (
                <li key={q.id} className="text-sm">
                  <button
                    onClick={() => handleVoteOnSimilar(q.id)}
                    className="text-blue-600 hover:text-blue-800 hover:underline focus:outline-none transition duration-150"
                  >
                    {q.title}
                  </button>
                </li>
              ))}
            </ul>
            <p className="text-xs text-blue-700 mt-3">Found a match? Click it to view and potentially vote!</p>
          </div>
        )}
      </div>

      {/* New Question Form */}
      <form onSubmit={handlePostQuestion} className="space-y-6">
         <FormInput
            label="Question Title"
            id="title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Be specific and imagine you're asking a friend"
            required
          />

         <FormTextarea
            label="Explain Your Question"
            id="body"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={8}
            placeholder="Provide details, background, and what you've already tried... Use simple terms!"
            required
          />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormSelect
            label="Topic"
            id="topic"
            options={topics}
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            required
          />

           <div>
             <label htmlFor="tags" className="block text-sm font-medium text-gray-700 mb-1">
               Tags (Optional)
             </label>
             <div className="flex flex-wrap gap-2 p-2 border border-gray-300 rounded-md focus-within:ring-1 focus-within:ring-blue-500 focus-within:border-blue-500">
               {tags.map(tag => (
                 <span
                   key={tag}
                   className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                 >
                   {tag}
                   <button
                     type="button"
                     onClick={() => removeTag(tag)}
                     className="ml-1 text-blue-600 hover:text-blue-800"
                   >
                     ×
                   </button>
                 </span>
               ))}
               <input
                 type="text"
                 id="tags"
                 value={tagInput}
                 onChange={handleTagInputChange}
                 onKeyDown={handleTagKeyDown}
                 className="flex-1 min-w-[120px] border-0 focus:ring-0 p-0 text-sm"
                 placeholder="Type tags and press Enter or comma..."
               />
             </div>
             <p className="mt-1 text-xs text-gray-500">
               Tags help others understand the type of explanation you prefer (like visual, story, analogy) or specific subtopics.
             </p>
           </div>
         </div>

        {error && submitting && (
          <div className="text-red-600 text-center p-3 bg-red-50 rounded">
            {error}
          </div>
        )}

        <div className="text-center pt-4">
          <button
            type="submit"
            className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-150"
            disabled={submitting}
          >
            {submitting ? 'Posting...' : 'Post Your Question'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AskQuestionPage; 