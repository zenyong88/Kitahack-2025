import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  Question, 
  Answer, 
  Topic, 
  getQuestions, 
  getAnswers, 
  getTopics 
} from '../utils/dataService';

const YourAnswersPage: React.FC = () => {
  const { user } = useAuth();
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Fetch questions, answers, and topics from API
        const [questionsData, answersData, topicsData] = await Promise.all([
          getQuestions(),
          getAnswers(),
          getTopics()
        ]);
        
        setQuestions(questionsData);
        setAnswers(answersData);
        setTopics(topicsData);
        setLoading(false);
        setError(null);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load data. Please try again later.');
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Filter answers given by the current user
  const userAnswers = user ? answers.filter(a => a.author === user.username) : [];

  // Get questions for those answers
  const answeredQuestions = userAnswers.map(answer => {
    const question = questions.find(q => (q.id) == (answer.questionId));
    return {
      answer,
      question
    };
  });

  // Apply topic filter if selected
  const filteredAnswers = selectedTopic
    ? answeredQuestions.filter(item => item.question?.topic === selectedTopic)
    : answeredQuestions;

  const handleTopicClick = (topicName: string) => {
    setSelectedTopic(selectedTopic === topicName ? null : topicName);
  };

  // Count user answers per topic for sidebar
  const topicCounts = topics.reduce((acc, topic) => {
    const count = answeredQuestions.filter(item => item.question?.topic === topic.name).length;
    acc[topic.name] = count;
    return acc;
  }, {} as Record<string, number>);

  if (loading) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-600 text-lg">Loading your answers...</p>
        {/* Optional: Add a spinner here */}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-10">
        <p className="text-red-600 text-lg">{error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row gap-8">
      {/* Left Sidebar: Topics Filter */}
      <aside className="w-full md:w-1/4 lg:w-1/5">
        <div className="bg-white p-4 rounded-lg shadow sticky top-24">
          <h2 className="text-xl font-semibold mb-4 text-gray-700">Filter by Topic</h2>
          <ul className="space-y-2">
            {topics.map(topic => (
              <li key={topic.id}>
                <button
                  onClick={() => handleTopicClick(topic.name)}
                  className={`w-full text-left p-2 rounded transition duration-150 focus:outline-none ${
                    selectedTopic === topic.name
                      ? 'bg-blue-100 text-blue-900 font-medium'
                      : 'text-blue-700 hover:text-blue-900 hover:bg-blue-50'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span>{topic.name}</span>
                    <span className="text-xs text-gray-500">
                      ({topicCounts[topic.name] || 0})
                    </span>
                  </div>
                </button>
              </li>
            ))}
          </ul>
          {selectedTopic && (
            <button
              onClick={() => setSelectedTopic(null)}
              className="mt-4 w-full text-sm text-blue-600 hover:text-blue-800"
            >
              Clear Filter
            </button>
          )}
        </div>
      </aside>

      {/* Main Content: User's Answers List */}
      <section className="w-full">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">Your Answers</h1>
          {selectedTopic && (
            <span className="text-sm text-gray-500">
              Filtered by: <span className="font-medium text-gray-700">{selectedTopic}</span>
            </span>
          )}
        </div>

        {filteredAnswers.length > 0 ? (
          <div className="space-y-6">
            {filteredAnswers.map(({ answer, question }) => (
              // Answer Card
              <div key={answer.id} className="bg-white border border-gray-200 p-5 rounded-lg shadow hover:shadow-lg transition duration-200">
                {/* Question Section */}
                <div className="mb-4">
                  {question ? (
                    <>
                      <Link to={`/question/${question.id}`} className="block mb-2">
                        <h3 className="text-xl font-semibold text-blue-700 hover:text-blue-900 transition duration-150">
                          {question.title}
                        </h3>
                      </Link>
                      <div className="text-sm text-gray-500 mb-2">
                        <span>Topic: <span className="font-medium text-gray-700">{question.topic}</span></span>
                        <span className="mx-2">•</span>
                        <span>Asked by: <span className="font-medium text-gray-700">{question.author}</span></span>
                        {question.solved && (
                          <span className="ml-4 px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                            Solved
                          </span>
                        )}
                        {!question.solved && (
                          <span className="ml-4 px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                            Open
                          </span>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="p-3 bg-yellow-50 text-yellow-700 rounded-md">
                      <p>Question ID: {answer.questionId} (Question may have been deleted)</p>
                    </div>
                  )}
                </div>

                {/* Answer Section */}
                <div className="border-t pt-4">
                  <h4 className="text-lg font-medium text-gray-800 mb-2">Your Answer:</h4>
                  <p className="text-gray-700 bg-gray-50 p-3 rounded">{answer.body.length > 200 ? `${answer.body.substring(0, 200)}...` : answer.body}</p>
                  <div className="mt-3 flex justify-between items-center">
                    <span className="text-sm text-gray-500">Votes: <span className="font-medium text-gray-700">{answer.votes}</span></span>
                    <Link
                      to={`/question/${answer.questionId}`}
                      className="text-sm text-blue-600 hover:text-blue-800"
                    >
                      View Full Question & Answer
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white border border-gray-200 p-6 rounded-lg shadow text-center">
            {selectedTopic ? (
              <>
                <p className="text-gray-600">You haven't answered any questions in this topic yet.</p>
                <button
                  onClick={() => setSelectedTopic(null)}
                  className="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded transition duration-300"
                >
                  Clear Filter
                </button>
              </>
            ) : (
              <>
                <p className="text-gray-600">You haven't answered any questions yet.</p>
                <Link
                  to="/"
                  className="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded transition duration-300"
                >
                  Find Questions to Answer
                </Link>
              </>
            )}
          </div>
        )}
      </section>
    </div>
  );
};

export default YourAnswersPage; 