import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import { useAuth } from '../contexts/AuthContext';
import { 
  Question, 
  Answer, 
  getQuestionById, 
  getAnswersByQuestionId, 
  saveAnswer, 
  updateAnswer,
  deleteAnswer,
  saveVote,
  getUserById,
  updateQuestion
} from '../utils/dataService';
import { explainLikeImFive } from '../utils/geminiService';

const QuestionPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [question, setQuestion] = useState<Question | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [newAnswer, setNewAnswer] = useState('');
  const [editingAnswerId, setEditingAnswerId] = useState<number | null>(null);
  const [editingAnswerText, setEditingAnswerText] = useState('');
  const [userVotes, setUserVotes] = useState<[number, number][]>([]);
  const [loading, setLoading] = useState(true);
  const [isGeneratingAIAnswer, setIsGeneratingAIAnswer] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Ref to store the timeout ID (use number for browser compatibility)
  const aiGenerationTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const fetchDataAndGenerateAIAnswer = async () => {
      try {
        // Reset states
        setLoading(true);
        setIsGeneratingAIAnswer(false);
        // Clear any pending AI generation timeout from previous renders/navigations
        if (aiGenerationTimeoutRef.current) {
          clearTimeout(aiGenerationTimeoutRef.current);
          aiGenerationTimeoutRef.current = null;
        }
        
        const questionId = parseInt(id ?? '0');
        if (questionId === 0) throw new Error('Invalid question ID');

        // Fetch question data
        const questionData = await getQuestionById(questionId);
        setQuestion(questionData);

        // Fetch answers for this question
        let answersData = await getAnswersByQuestionId(questionId);
        setAnswers(answersData);

        // Fetch user's votes
        const userData = await getUserById(parseInt(user.id));
        setUserVotes(userData.question_vote || []);
        
        // Check if ELI5 Helper answer exists
        const hasAIAnswer = answersData.some(a => a.author === 'ELI5 Helper');
        
        // Schedule AI answer generation if needed
        if (!hasAIAnswer && questionData && !questionData.solved) {
          console.log("Scheduling ELI5 answer generation in 1 seconds...");
          aiGenerationTimeoutRef.current = setTimeout(async () => {
            try {
              setIsGeneratingAIAnswer(true); // Show loading message now
              console.log("Attempting to generate ELI5 answer for question:", questionData.title);
              const explanation = await explainLikeImFive(questionData.title, questionData.body);
              
              if (explanation) {
                console.log("ELI5 explanation generated:", explanation);
                const aiAnswerData = {
                  questionId: questionId,
                  author: 'ELI5 Helper',
                  body: explanation,
                  votes: 0,
                };
                // Save the AI answer (error handling within the timeout)
                try {
                  const savedAIAnswer = await saveAnswer(aiAnswerData);
                  console.log("ELI5 answer saved successfully.");
                  setAnswers(prevAnswers => [...prevAnswers, savedAIAnswer]);
                } catch (saveError) {
                  console.error("Failed to save ELI5 answer:", saveError);
                }
              } else {
                console.log("Failed to generate ELI5 explanation or API key missing.");
              }
            } catch (generateError) {
                console.error("Error during delayed AI answer generation:", generateError);
                // Optionally set an error state specific to AI generation failure
            } finally {
                 setIsGeneratingAIAnswer(false); // Hide loading message regardless of outcome
                 aiGenerationTimeoutRef.current = null; // Clear the ref after execution
            }
          }, 1000); // 1-second delay
        }

        setLoading(false);
        setNewAnswer('');
        setEditingAnswerId(null);
        setEditingAnswerText('');
        setError(null);
      } catch (err) {
        setLoading(false);
        setIsGeneratingAIAnswer(false); // Ensure loading is off on error
        // Clear timeout on error too
        if (aiGenerationTimeoutRef.current) {
          clearTimeout(aiGenerationTimeoutRef.current);
          aiGenerationTimeoutRef.current = null;
        }
        setError('Failed to load question data. Please try again later.');
        console.error('Error fetching question data or scheduling AI answer:', err);
      }
    };

    fetchDataAndGenerateAIAnswer();

    // Cleanup function to clear timeout on unmount or dependency change
    return () => {
      if (aiGenerationTimeoutRef.current) {
        console.log("Clearing scheduled AI answer generation due to component unmount/re-render.");
        clearTimeout(aiGenerationTimeoutRef.current);
        aiGenerationTimeoutRef.current = null;
      }
    };
  }, [id, user, navigate]);

  const handleAnswerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnswer.trim() || !question || !user) return;

    // Check if user is the question author
    if (question.author === user.username) {
      alert("You cannot answer your own question!");
      return;
    }

    // Check if user has already answered this question
    const existingAnswer = answers.find(a => a.author === user.username);
    if (existingAnswer) {
      alert("You have already answered this question. You can edit your existing answer instead.");
      return;
    }

    try {
      const answerData = {
        questionId: parseInt(id ?? '0'),
        author: user.username,
        body: newAnswer,
        votes: 0,
      };

      // Save the answer to the server
      const savedAnswer = await saveAnswer(answerData);
      
      // Update the local state
      setAnswers([...answers, savedAnswer]);
      setNewAnswer('');
    } catch (err) {
      console.error('Error submitting answer:', err);
      alert('Failed to submit your answer. Please try again.');
    }
  };

  const handleEditAnswer = (answer: Answer) => {
    setEditingAnswerId(answer.id);
    setEditingAnswerText(answer.body);
  };

  const handleUpdateAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAnswerId || !editingAnswerText.trim()) return;

    try {
      const answerToUpdate = answers.find(a => a.id === editingAnswerId);
      if (!answerToUpdate) return;

      const updatedAnswer = {
        ...answerToUpdate,
        body: editingAnswerText
      };

      // Update the answer on the server
      const savedAnswer = await updateAnswer(updatedAnswer);
      
      // Update the local state
      setAnswers(answers.map(a => a.id === editingAnswerId ? savedAnswer : a));
      setEditingAnswerId(null);
      setEditingAnswerText('');
    } catch (err) {
      console.error('Error updating answer:', err);
      alert('Failed to update your answer. Please try again.');
    }
  };

  const handleCancelEdit = () => {
    setEditingAnswerId(null);
    setEditingAnswerText('');
  };

  const handleDeleteAnswer = async (answerId: number) => {
    if (!window.confirm('Are you sure you want to delete this answer?')) {
      return;
    }

    try {
      await deleteAnswer(answerId);
      // Update the local state by removing the deleted answer
      setAnswers(answers.filter(a => a.id !== answerId));
    } catch (err) {
      console.error('Error deleting answer:', err);
      alert('Failed to delete your answer. Please try again.');
    }
  };

  const handleVote = async (answerId: number) => {
    try {
      if (!user || !question) return;
      
      const questionId = parseInt(id ?? '0');
      
      // Check if user has already voted for this question
      const hasVoted = userVotes.some(([qId, _]) => qId === questionId);
      if (hasVoted) {
        alert("You have already voted for an answer to this question!");
        return;
      }
      
      // Save the vote
      await saveVote(parseInt(user.id), questionId, answerId);
      
      // Update local state
      setUserVotes([...userVotes, [questionId, answerId]]);
      
      // Update the answer's vote count in the local state
      setAnswers(answers.map(a => 
        a.id === answerId ? {...a, votes: a.votes + 1} : a
      ));
      
      // If user is question author, mark question as solved
      if (isQuestionAuthor) {
        // Update the question on the server to mark it as solved
        const updatedQuestion = { ...question, solved: true };
        const response = await updateQuestion(updatedQuestion);
        // Update local state
        setQuestion(response);
        alert("You've marked this answer as the best answer. The question is now solved!");
      }
    } catch (err) {
      console.error('Error voting for answer:', err);
      alert('Failed to vote for the answer. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-600 text-lg">Loading question...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-10">
        <p className="text-red-600 text-lg">{error}</p>
      </div>
    );
  }

  if (!question) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-600 text-lg">Question not found</p>
      </div>
    );
  }

  const isQuestionAuthor = user.username === question.author;
  const userAnswer = answers.find(a => a.author === user.username);
  const questionId = parseInt(id ?? '0');
  const hasVotedForQuestion = userVotes.some(([qId, _]) => qId === questionId);
  const userVotedAnswerId = hasVotedForQuestion 
    ? userVotes.find(([qId, _]) => qId === questionId)?.[1]
    : null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Question Display Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4 text-gray-800">{question.title}</h1>
        <p className="text-gray-600 mb-4">{question.body}</p>
        <div className="flex items-center text-sm text-gray-500">
          <span>Asked by: {question.author}</span>
          <span className="mx-2">•</span>
          <span>Topic: {question.topic}</span>
          {question.solved ? (
            <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
              Solved
            </span>
          ) : (
            <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
              Open
            </span>
          )}
        </div>
      </div>

      {/* Display message while generating AI answer */}
      {isGeneratingAIAnswer && (
        <div className="my-4 p-4 bg-blue-50 border border-blue-200 rounded-md text-center">
          <p className="text-blue-700">Generating an ELI5 explanation from our AI helper...</p>
        </div>
      )}

      {/* Answering Section (only show if user hasn't answered yet and question isn't solved) */}
      {!isQuestionAuthor && !question.solved && !userAnswer && (
        <form onSubmit={handleAnswerSubmit} className="mb-8">
          <h2 className="text-2xl font-semibold mb-4 text-gray-800">Submit Your ELI5 Answer</h2>
          <textarea
            value={newAnswer}
            onChange={(e) => setNewAnswer(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-150 shadow-sm text-base"
            rows={6}
            placeholder="Explain it like I'm 5... provide clear, simple explanations."
            required
          />
          <button
            type="submit"
            className="mt-4 inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150"
          >
            Submit Answer
          </button>
        </form>
      )}

      {/* Answers Display Section */}
      <div>
        <h2 className="text-2xl font-semibold mb-5 text-gray-800">Answers</h2>
        {answers.length === 0 && !userAnswer && (
          <p className="text-gray-600 p-4">No answers yet. Be the first to answer!</p>
        )}
        {answers.length > 0 && (
          <div className="space-y-6">
            {answers.map(answer => (
              <div 
                key={answer.id} 
                className={`border ${userVotedAnswerId === answer.id ? 'border-green-300 bg-green-50' : 'border-gray-200 bg-gray-50'} p-5 rounded-lg shadow-sm relative`}
              >
                {editingAnswerId === answer.id ? (
                  <form onSubmit={handleUpdateAnswer} className="space-y-4">
                    <textarea
                      value={editingAnswerText}
                      onChange={(e) => setEditingAnswerText(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-150 shadow-sm text-base"
                      rows={6}
                      required
                    />
                    <div className="flex space-x-4">
                      <button
                        type="submit"
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        Save Changes
                      </button>
                      <button
                        type="button"
                        onClick={handleCancelEdit}
                        className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                ) : (
                  <>
                    <div className="prose prose-sm max-w-none text-gray-700 text-base leading-relaxed whitespace-pre-wrap">
                      <ReactMarkdown>{answer.body}</ReactMarkdown>
                    </div>
                    <div className="mt-4 pt-4 border-t border-gray-200 flex justify-between items-center">
                      <span className="text-sm text-gray-500">by {answer.author}</span>
                      <div className="flex items-center space-x-4">
                        {answer.author === user.username && !question.solved && (
                          <>
                            <button
                              onClick={() => handleEditAnswer(answer)}
                              className="text-sm text-blue-600 hover:text-blue-800"
                            >
                              Edit Answer
                            </button>
                            <button
                              onClick={() => handleDeleteAnswer(answer.id)}
                              className="text-sm text-red-600 hover:text-red-800"
                            >
                              Delete Answer
                            </button>
                          </>
                        )}
                        {/* Show vote button only if user hasn't voted yet */}
                        {/* For question author: show only if not solved */}
                        {/* For other users: show regardless of solved status */}
                        {!hasVotedForQuestion && (
                          (isQuestionAuthor && !question.solved) || (!isQuestionAuthor) ? (
                            <button
                              onClick={() => handleVote(answer.id)}
                              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-150"
                            >
                              {isQuestionAuthor ? 'Mark as Best Answer' : 'Vote as Best Answer'}
                            </button>
                          ) : null
                        )}
                        <div className="flex flex-col items-end">
                          <span className="text-gray-500 text-sm">Votes: {answer.votes}</span>
                          {userVotedAnswerId === answer.id && (
                            <span className="text-xs text-green-600 font-medium">You voted for this</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default QuestionPage; 