import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, useParams } from 'react-router-dom';
import { 
  getExploreData, 
  saveExploreAnswer, 
  voteExploreAnswer, 
  updateExploreAnswer,
  deleteExploreAnswer 
} from '../utils/dataService';
import { useAuth } from '../contexts/AuthContext';

// Define Types
interface ExploreTopic {
  id: string;
  name: string;
  questions: string[];
  answers: {
    id: string;
    questionIndex: number;
    author: string;
    body: string;
    votes: number;
  }[];
  question_votes?: Array<[string, number, string]>;
}

const ExploreTopicDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { topicId } = useParams<{ topicId: string }>();
  const { user } = useAuth();
  
  const [topic, setTopic] = useState<ExploreTopic | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [newAnswer, setNewAnswer] = useState('');
  const [votedAnswers, setVotedAnswers] = useState<{ [questionIndex: number]: string }>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editingAnswerId, setEditingAnswerId] = useState<string | null>(null);
  const [editingAnswerText, setEditingAnswerText] = useState('');
  
  // Check if user is logged in
  useEffect(() => {
    if (!user) {
      navigate('/login', { state: { from: location } });
    }
  }, [user, navigate, location]);
  
  // Get state passed from ExploreTopicsPage
  const state = location.state as { 
    grade: string; 
    subject: string; 
    role: 'Educator' | 'Student';
  } | null;
  
  // Redirect if no state is provided
  useEffect(() => {
    if (!state || !state.grade || !state.subject || !state.role || !topicId) {
      navigate('/explore');
    }
  }, [state, topicId, navigate]);

  // Fetch topic data
  useEffect(() => {
    const fetchTopic = async () => {
      if (!state || !topicId) return;
      
      try {
        setLoading(true);
        const data = await getExploreData();
        const key = `${state.grade}-${state.subject}` as keyof typeof data.topicsByGradeSubject;
        const topics = data.topicsByGradeSubject[key] || [];
        
        const foundTopic = topics.find(t => String(t.id) === topicId);
        
        if (!foundTopic) {
          setError('Topic not found');
          setLoading(false);
          return;
        }
        
        // Convert to the ExploreTopic type
        const questions = Array.isArray(foundTopic.questions) 
          ? foundTopic.questions 
          // @ts-ignore - Handle legacy data format with single question
          : (foundTopic.question ? [foundTopic.question] : ["No question available"]);
        
        const typedTopic: ExploreTopic = {
          id: String(foundTopic.id),
          name: foundTopic.name,
          questions,
          answers: foundTopic.answers.map(answer => ({
            id: String(answer.id),
            questionIndex: typeof answer.questionIndex === 'number' ? answer.questionIndex : 0,
            author: answer.author,
            body: answer.body,
            votes: answer.votes
          })),
          question_votes: foundTopic.question_votes || []
        };
        
        setTopic(typedTopic);
        
        // If user is logged in, check which questions they've already voted on
        if (user) {
          const votedQuestions: { [questionIndex: number]: string } = {};
          const userVotes = typedTopic.question_votes?.filter(([uid]) => uid === user.id) || [];
          
          userVotes.forEach(([, qIndex, answerId]) => {
            votedQuestions[qIndex] = answerId;
          });
          
          setVotedAnswers(votedQuestions);
        }
        
        setLoading(false);
      } catch (err) {
        console.error('Error fetching topic:', err);
        setError('Failed to load topic. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchTopic();
  }, [state, topicId, user]);
  
  const handleQuestionChange = (direction: 'next' | 'prev') => {
    if (!topic) return;
    
    // Cancel any ongoing edits when changing questions
    setEditingAnswerId(null);
    setEditingAnswerText('');
    
    if (direction === 'next' && currentQuestionIndex < topic.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else if (direction === 'prev' && currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };
  
  const handleEducatorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnswer.trim() || !topic || !user || !state) return;
    
    // Check if user has already answered this question
    const userHasAnswered = topic.answers.some(
      answer => answer.questionIndex === currentQuestionIndex && answer.author === user.username
    );
    
    if (userHasAnswered) {
      alert("You have already submitted an explanation for this question. You can edit your existing explanation instead.");
      return;
    }
    
    try {
      // Prepare the answer object
      const answer = {
        author: user.username,
        body: newAnswer,
        votes: 0,
        questionIndex: currentQuestionIndex
      };
      
      // Save answer to the database
      await saveExploreAnswer(
        `${state.grade}-${state.subject}`,
        topic.id,
        answer
      );
      
      // Update local state with the new answer
      const tempNewAnswer = {
        id: `explore-${Date.now()}`,
        author: answer.author,
        body: answer.body,
        votes: answer.votes,
        questionIndex: answer.questionIndex
      };
      
      setTopic(prev => {
        if (!prev) return null;
        return {
          ...prev,
          answers: [...prev.answers, tempNewAnswer]
        };
      });
      
      setNewAnswer('');
      
      // Fetch updated data to ensure we have the correct IDs
      const updatedData = await getExploreData();
      const key = `${state.grade}-${state.subject}` as keyof typeof updatedData.topicsByGradeSubject;
      const topics = updatedData.topicsByGradeSubject[key] || [];
      const updatedTopic = topics.find(t => String(t.id) === topicId);
      
      if (updatedTopic) {
        // Update with the latest data from the server
        const questions = Array.isArray(updatedTopic.questions) 
          ? updatedTopic.questions 
          // @ts-ignore
          : (updatedTopic.question ? [updatedTopic.question] : ["No question available"]);
        
        setTopic({
          id: String(updatedTopic.id),
          name: updatedTopic.name,
          questions,
          answers: updatedTopic.answers.map(answer => ({
            id: String(answer.id),
            questionIndex: typeof answer.questionIndex === 'number' ? answer.questionIndex : 0,
            author: answer.author,
            body: answer.body,
            votes: answer.votes
          })),
          question_votes: updatedTopic.question_votes || []
        });
      }
      
      alert('Your explanation has been submitted!');
    } catch (err) {
      console.error('Error submitting educator answer:', err);
      alert('Failed to submit your explanation. Please try again.');
    }
  };
  
  const handleStudentVote = async (answerId: string) => {
    if (!user || !topic || !state || votedAnswers[currentQuestionIndex]) {
      return; // Already voted on this question or not logged in
    }
    
    try {
      // Save vote to the database
      await voteExploreAnswer(
        `${state.grade}-${state.subject}`,
        topic.id,
        answerId,
        user.id,
        currentQuestionIndex
      );
      
      // Update local state
      setTopic(prev => {
        if (!prev) return null;
        
        // Update the answer votes
        const updatedAnswers = prev.answers.map(a =>
          a.id === answerId ? { ...a, votes: a.votes + 1 } : a
        );
        
        // Update question_votes array
        const updatedQuestionVotes: [string, number, string][] = [
          ...(prev.question_votes || []),
          [user.id, currentQuestionIndex, answerId]
        ];
        
        return {
          ...prev,
          answers: updatedAnswers,
          question_votes: updatedQuestionVotes
        };
      });
      
      // Update votedAnswers state
      setVotedAnswers(prev => ({
        ...prev,
        [currentQuestionIndex]: answerId
      }));
      
      alert('Your vote has been recorded!');
    } catch (err) {
      console.error('Error submitting vote:', err);
      alert('Failed to submit your vote. Please try again.');
    }
  };
  
  const handleEditAnswer = (answer: {
    id: string;
    questionIndex: number;
    author: string;
    body: string;
    votes: number;
  }) => {
    setEditingAnswerId(answer.id);
    setEditingAnswerText(answer.body);
  };
  
  const handleCancelEdit = () => {
    setEditingAnswerId(null);
    setEditingAnswerText('');
  };
  
  const handleUpdateAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAnswerId || !editingAnswerText.trim() || !topic || !state) return;
    
    try {
      // Update the answer on the server
      await updateExploreAnswer(
        `${state.grade}-${state.subject}`,
        topic.id,
        editingAnswerId,
        editingAnswerText
      );
      
      // Update the local state
      setTopic(prev => {
        if (!prev) return null;
        return {
          ...prev,
          answers: prev.answers.map(answer => 
            answer.id === editingAnswerId 
              ? { ...answer, body: editingAnswerText } 
              : answer
          )
        };
      });
      
      // Reset the editing state
      setEditingAnswerId(null);
      setEditingAnswerText('');
      alert('Your explanation has been updated!');
    } catch (err) {
      console.error('Error updating answer:', err);
      alert('Failed to update your explanation. Please try again.');
    }
  };
  
  const handleDeleteAnswer = async (answerId: string) => {
    if (!window.confirm('Are you sure you want to delete this explanation?')) {
      return;
    }
    
    if (!topic || !state) return;
    
    try {
      // Delete the answer on the server
      await deleteExploreAnswer(
        `${state.grade}-${state.subject}`,
        topic.id,
        answerId
      );
      
      // Update the local state
      setTopic(prev => {
        if (!prev) return null;
        return {
          ...prev,
          answers: prev.answers.filter(answer => answer.id !== answerId),
          // Also remove any votes for this answer
          question_votes: (prev.question_votes || []).filter(
            ([_, __, aid]) => aid !== answerId
          )
        };
      });
      
      alert('Your explanation has been deleted.');
    } catch (err) {
      console.error('Error deleting answer:', err);
      alert('Failed to delete your explanation. Please try again.');
    }
  };
  
  const handleBackClick = () => {
    navigate('/explore/topics', { state });
  };
  
  if (loading) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-600 text-lg">Loading topic...</p>
      </div>
    );
  }
  
  if (error || !topic || !state) {
    return (
      <div className="text-center py-10">
        <p className="text-red-600 text-lg">{error || 'Topic not found'}</p>
        <button 
          onClick={() => navigate('/explore')} 
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Back to Explore
        </button>
      </div>
    );
  }
  
  const roleColor = state.role === 'Educator' ? 'purple' : 'teal';
  
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-800">{topic.name}</h1>
        <button 
          onClick={handleBackClick}
          className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
        >
          Back to Topics
        </button>
      </div>
      
      {/* Selection Info */}
      <div className={`p-4 bg-${roleColor}-50 border border-${roleColor}-200 rounded-lg`}>
        <div className="flex flex-wrap gap-3 text-sm">
          <span className={`px-3 py-1 bg-${roleColor}-100 text-${roleColor}-800 font-medium rounded-full`}>
            Role: {state.role}
          </span>
          <span className="px-3 py-1 bg-blue-100 text-blue-800 font-medium rounded-full">
            Grade: {state.grade}
          </span>
          <span className="px-3 py-1 bg-green-100 text-green-800 font-medium rounded-full">
            Subject: {state.subject}
          </span>
        </div>
      </div>

      {/* Question Navigation */}
      <div className="flex justify-between items-center mb-4">
        <button 
          onClick={() => handleQuestionChange('prev')}
          disabled={currentQuestionIndex === 0}
          className={`px-3 py-1 rounded ${currentQuestionIndex === 0 ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-blue-500 text-white hover:bg-blue-600'}`}
        >
          Previous Question
        </button>
        <span className="text-sm text-gray-600">
          Question {currentQuestionIndex + 1} of {topic.questions.length}
        </span>
        <button 
          onClick={() => handleQuestionChange('next')}
          disabled={currentQuestionIndex === topic.questions.length - 1}
          className={`px-3 py-1 rounded ${currentQuestionIndex === topic.questions.length - 1 ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-blue-500 text-white hover:bg-blue-600'}`}
        >
          Next Question
        </button>
      </div>
      
      {/* Current Question Box */}
      <div className="text-gray-800 mb-6 bg-yellow-100 p-4 rounded-md border border-yellow-200 shadow-sm">
        <p className="font-medium">Question:</p>
        <p>{topic.questions[currentQuestionIndex]}</p>
      </div>
      
      {/* Educator View: Submit Answer Form */}
      {state.role === 'Educator' && !editingAnswerId && (
        <>
          {topic.answers.some(
            answer => answer.questionIndex === currentQuestionIndex && answer.author === user?.username
          ) ? (
            <div className="p-4 border border-purple-200 rounded-md bg-purple-50">
              <h4 className="text-lg font-semibold mb-3 text-purple-800">Your Explanation</h4>
              <p className="text-purple-800 mb-2">You have already submitted an explanation for this question.</p>
              <p className="text-gray-600">Find your explanation below to edit or update it.</p>
            </div>
          ) : (
            <form onSubmit={handleEducatorSubmit} className="p-4 border border-purple-200 rounded-md bg-purple-50">
              <h4 className="text-lg font-semibold mb-3 text-purple-800">Submit Your ELI5 Explanation for Question {currentQuestionIndex + 1}</h4>
              <textarea
                value={newAnswer}
                onChange={(e) => setNewAnswer(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded mb-3 focus:ring-purple-500 focus:border-purple-500 shadow-sm"
                rows={5}
                placeholder="Explain this topic simply and clearly..."
                required
              />
              <button 
                type="submit" 
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition duration-150"
              >
                Submit Explanation
              </button>
            </form>
          )}
        </>
      )}

      {/* Educator View: Edit Answer Form */}
      {state.role === 'Educator' && editingAnswerId && (
        <form onSubmit={handleUpdateAnswer} className="p-4 border border-purple-200 rounded-md bg-purple-50">
          <h4 className="text-lg font-semibold mb-3 text-purple-800">Edit Your Explanation</h4>
          <textarea
            value={editingAnswerText}
            onChange={(e) => setEditingAnswerText(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded mb-3 focus:ring-purple-500 focus:border-purple-500 shadow-sm"
            rows={5}
            required
          />
          <div className="flex gap-2">
            <button 
              type="submit" 
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition duration-150"
            >
              Update Explanation
            </button>
            <button 
              type="button"
              onClick={handleCancelEdit}
              className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Answers for the current question */}
      <div>
        <h4 className="text-xl font-semibold mb-4 text-gray-700 border-t pt-4">Explanations for Question {currentQuestionIndex + 1}</h4>
        {topic.answers.filter(answer => answer.questionIndex === currentQuestionIndex).length > 0 ? (
          <div className="space-y-4">
            {topic.answers
              .filter(answer => answer.questionIndex === currentQuestionIndex)
              .map(answer => (
                // Answer Card
                <div key={answer.id} className="border border-gray-200 bg-gray-50 p-4 rounded-lg shadow-sm relative transition duration-150 hover:shadow-md">
                  <p className="text-gray-800 text-base leading-relaxed whitespace-pre-wrap mb-3">{answer.body}</p>
                  <div className="text-xs text-gray-500 border-t pt-2 flex justify-between items-center">
                    <span>By: <span className="font-medium">{answer.author}</span></span>
                    <span>Votes: <span className="font-semibold text-blue-600">{answer.votes}</span></span>
                  </div>
                  
                  {/* Student View: Vote Button */}
                  {state.role === 'Student' && !votedAnswers[currentQuestionIndex] && (
                    <button 
                      onClick={() => handleStudentVote(answer.id)}
                      className="mt-2 inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-teal-500 transition duration-150"
                    >
                      Vote for this explanation
                    </button>  
                  )}
                  
                  {/* Show if the student has already voted for this answer */}
                  {votedAnswers[currentQuestionIndex] === answer.id && (
                    <span className="mt-2 block text-xs text-teal-600 font-semibold">
                      ✓ You voted for this explanation
                    </span>
                  )}
                  
                  {/* Educator Actions: Edit and Delete */}
                  {state.role === 'Educator' && answer.author === user?.username && !editingAnswerId && (
                    <div className="mt-2 flex gap-2">
                      <button 
                        onClick={() => handleEditAnswer(answer)}
                        className="inline-flex items-center px-2 py-1 border border-blue-300 text-xs font-medium rounded shadow-sm text-blue-700 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-blue-500 transition duration-150"
                      >
                        Edit
                      </button>
                      <button 
                        onClick={() => handleDeleteAnswer(answer.id)}
                        className="inline-flex items-center px-2 py-1 border border-red-300 text-xs font-medium rounded shadow-sm text-red-700 bg-red-50 hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-red-500 transition duration-150"
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              ))}
          </div>
        ) : (
          <p className="text-gray-600 p-4 rounded-md bg-gray-50">
            No explanations yet for this question. 
            {state.role === 'Educator' ? ' Be the first to submit one!' : ' Check back later for educator explanations.'}
          </p>
        )}
      </div>
    </div>
  );
};

export default ExploreTopicDetailPage; 