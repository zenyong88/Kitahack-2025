import React, { createContext, useState, useContext, ReactNode } from 'react';

// Define the shape of the context data
interface AuthContextType {
  user: any | null; // Replace 'any' with your User type
  login: (userData: any) => void; // Replace 'any' with User data type
  logout: () => void;
  loading: boolean;
}

// Create the context with a default value
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Define the props for the provider component
interface AuthProviderProps {
  children: ReactNode;
}

// Create the provider component
const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<any | null>(null); // Replace 'any' with User type
  const [loading, setLoading] = useState<boolean>(true); // Simulate initial loading state

  // Simulate checking auth status on mount (e.g., check local storage, call API)
  React.useEffect(() => {
    // Placeholder: Simulate checking auth persistence
    const storedUser = localStorage.getItem('eli5_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error("Failed to parse stored user data:", error);
        localStorage.removeItem('eli5_user');
      }
    }
    setLoading(false); // Finished checking
  }, []);

  // Login function (placeholder)
  const login = (userData: any) => {
    console.log('Logging in user:', userData);
    // TODO: Implement actual login logic (API call, set token, etc.)
    setUser(userData); // Set user state
    localStorage.setItem('eli5_user', JSON.stringify(userData)); // Persist user (simple example)
  };

  // Logout function (placeholder)
  const logout = () => {
    console.log('Logging out user');
    // TODO: Implement actual logout logic (clear token, API call, etc.)
    setUser(null);
    localStorage.removeItem('eli5_user'); // Remove persisted user
  };

  // Value provided by the context
  const value = {
    user,
    login,
    logout,
    loading,
  };

  // Don't render children until initial auth check is complete
  if (loading) {
    return <div>Loading Authentication...</div>; // Or a spinner component
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use the Auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthProvider; 