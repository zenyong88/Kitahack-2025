import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    // Header bar: Light blue background, padding, shadow
    <header className="bg-blue-100 text-blue-800 shadow-md sticky top-0 z-50">
      <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
        {/* Left Side: Logo and Navigation Links */}
        <div className="flex items-center space-x-10"> {/* Increased spacing */} 
          {/* Logo */}
          <Link to="/" className="text-2xl font-bold text-blue-700 hover:text-blue-900 transition duration-150">ELI5 Arena</Link>

          {/* Navigation Links as Buttons */} 
          <div className="hidden md:flex space-x-4">
             <Link 
                to="/leaderboard" 
                // Increased padding, added solid background
                className="text-base font-medium px-6 py-3 rounded-md bg-blue-200 text-blue-900 hover:bg-blue-300 transition duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
             >
                Leaderboard
             </Link>
             {user && (
               <Link 
                 to="/your-questions" 
                 // Increased padding, added solid background
                 className="text-base font-medium px-6 py-3 rounded-md bg-blue-200 text-blue-900 hover:bg-blue-300 transition duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
               >
                  Your Questions
               </Link>
             )}
             {user && (
               <Link 
                 to="/your-answers" 
                 // Increased padding, added solid background
                 className="text-base font-medium px-6 py-3 rounded-md bg-blue-200 text-blue-900 hover:bg-blue-300 transition duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
               >
                  Your Answers
               </Link>
             )}
             <Link 
               to="/explore" 
               // Increased padding, added solid background
               className="text-base font-medium px-6 py-3 rounded-md bg-blue-200 text-blue-900 hover:bg-blue-300 transition duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
             >
                Explore
             </Link>
          </div>
        </div>

        {/* Right Side: Auth Links/Buttons */}
        <div className="flex items-center space-x-4">
          {user ? (
            <>
              <span className="mr-2 font-medium">Welcome, {user.username}!</span>
              <button 
                onClick={handleLogout}
                className="text-sm font-medium bg-red-500 hover:bg-red-600 text-white px-5 py-2 rounded-md transition duration-150 shadow focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
              >
                Logout
              </button>
            </>
          ) : (
            <div className="flex space-x-4">
              <Link 
                to="/signup" 
                className="text-base font-medium px-6 py-3 rounded-md bg-green-500 text-white hover:bg-green-600 transition duration-150 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
              >
                Sign Up
              </Link>
              <Link 
                to="/login" 
                className="text-base font-medium px-6 py-3 rounded-md bg-blue-200 text-blue-900 hover:bg-blue-300 transition duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Login
              </Link>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;