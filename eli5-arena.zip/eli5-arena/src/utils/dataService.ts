import axios from 'axios';

// Base URL for the json-server API
const API_URL = 'http://localhost:3001';

// Interfaces
export interface Question {
  id: number;
  title: string;
  author: string;
  topic: string;
  tags: string[];
  body: string;
  solved: boolean;
}

export interface Answer {
  id: number;
  questionId: number;
  author: string;
  body: string;
  votes: number;
}

export interface User {
  id: number;
  username: string;
  email: string;
  password: string;
  avatar: string;
  score: number;
  votes: number;
  questionsAsked: number;
  answersGiven: number;
  bestAnswers: number;
  exploreScore: number;
  exploreVotes: number;
  exploreAnswers: number;
  exploreBestAnswers: number;
  joinDate: string;
  question_vote?: [number, number][];
}

export interface Topic {
  id: number;
  name: string;
}

export interface ExploreData {
  topicsByGradeSubject: Record<string, Array<{
    id: number;
    name: string;
    questions?: string[]; // New format with array of questions
    question?: string;    // Old format with single question
    answers: Array<{
      id: number;
      questionIndex?: number; // Index of question this answer responds to (new format)
      author: string;
      body: string;
      votes: number;
    }>;
    question_votes?: Array<[string, number, string]>; // Array of [userId, questionIndex, answerId] tuples
  }>>;
}

// Helper function to generate unique time-based IDs
const generateUniqueId = (): string => {
  // Combine current timestamp with a random number to ensure uniqueness
  return (`${Date.now()}${Math.floor(Math.random() * 1000)}`);
};

// Questions API
export const getQuestions = async (): Promise<Question[]> => {
  const response = await axios.get(`${API_URL}/questions`);
  return response.data;
};

export const getQuestionById = async (id: number): Promise<Question> => {
  const response = await axios.get(`${API_URL}/questions/${id}`);
  return response.data;
};

export const saveQuestion = async (question: Omit<Question, 'id'>): Promise<Question> => {
  // Create a new question object with a unique time-based ID
  const questionWithId = {
    ...question,
    id: generateUniqueId()
  };
  
  const response = await axios.post(`${API_URL}/questions`, questionWithId);
  return response.data;
};

export const updateQuestion = async (question: Question): Promise<Question> => {
  const response = await axios.put(`${API_URL}/questions/${question.id}`, question);
  return response.data;
};

// Answers API
export const getAnswers = async (): Promise<Answer[]> => {
  const response = await axios.get(`${API_URL}/answers`);
  return response.data;
};

export const getAnswersByQuestionId = async (questionId: number): Promise<Answer[]> => {
  const response = await axios.get(`${API_URL}/answers?questionId=${questionId}`);
  return response.data;
};

export const saveAnswer = async (answer: Omit<Answer, 'id'>): Promise<Answer> => {
  // Create a new answer object with a unique time-based ID
  const answerWithId = {
    ...answer,
    id: generateUniqueId()
  };
  
  const response = await axios.post(`${API_URL}/answers`, answerWithId);
  return response.data;
};

export const updateAnswer = async (answer: Answer): Promise<Answer> => {
  const response = await axios.put(`${API_URL}/answers/${answer.id}`, answer);
  return response.data;
};

export const deleteAnswer = async (answerId: number): Promise<void> => {
  await axios.delete(`${API_URL}/answers/${answerId}`);
};

// Users API
export const getUsers = async (): Promise<User[]> => {
  const response = await axios.get(`${API_URL}/users`);
  return response.data;
};

export const getUserById = async (id: number): Promise<User> => {
  const response = await axios.get(`${API_URL}/users/${id}`);
  return response.data;
};

export const loginUser = async (username: string, password: string): Promise<User> => {
  const users = await getUsers();
  const user = users.find(u => u.username === username && u.password === password);
  
  if (!user) {
    throw new Error('Invalid username or password');
  }
  
  return user;
};

export const createUser = async (userData: Omit<User, 'id'>): Promise<User> => {
  // Check if username or email already exists
  const users = await getUsers();
  if (users.some(u => u.username === userData.username)) {
    throw new Error('Username already exists');
  }
  if (users.some(u => u.email === userData.email)) {
    throw new Error('Email already exists');
  }

  // Create a new user object with a unique time-based ID
  const userWithId = {
    ...userData,
    id: generateUniqueId(),
    score: 0,
    votes: 0,
    questionsAsked: 0,
    answersGiven: 0,
    bestAnswers: 0,
    exploreScore: 0,
    exploreVotes: 0,
    exploreAnswers: 0,
    exploreBestAnswers: 0,
    joinDate: new Date().toISOString(),
    question_vote: []
  };
  
  const response = await axios.post(`${API_URL}/users`, userWithId);
  return response.data;
};

export const updateUser = async (user: User): Promise<User> => {
  const response = await axios.put(`${API_URL}/users/${user.id}`, user);
  return response.data;
};

// Topics API
export const getTopics = async (): Promise<Topic[]> => {
  const response = await axios.get(`${API_URL}/topics`);
  return response.data;
};

// Explore Data API
export const getExploreData = async (): Promise<ExploreData> => {
  const response = await axios.get(`${API_URL}/exploreData`);
  return response.data;
};

// Save an answer to a topic in explore mode
export const saveExploreAnswer = async (
  gradeSubject: string,
  topicId: string,
  answer: { author: string; body: string; votes: number; questionIndex: number }
): Promise<void> => {
  // First, get current explore data
  const exploreDataResponse = await axios.get(`${API_URL}/exploreData`);
  const exploreData = exploreDataResponse.data;

  // Find the topic and add the answer
  const topicsByGradeSubject = exploreData.topicsByGradeSubject;
  
  if (topicsByGradeSubject[gradeSubject]) {
    const topicIndex = topicsByGradeSubject[gradeSubject].findIndex(
      (topic: any) => String(topic.id) === topicId
    );
    
    if (topicIndex !== -1) {
      const topic = topicsByGradeSubject[gradeSubject][topicIndex];
      
      // Ensure topic has a questions array (backward compatibility)
      if (!topic.questions && topic.question) {
        topic.questions = [topic.question];
      }
      
      // Create new answer with unique ID
      const newAnswer = {
        ...answer,
        id: `explore-${Date.now()}`
      };
      
      // Add the answer to the topic
      topicsByGradeSubject[gradeSubject][topicIndex].answers.push(newAnswer);
      
      // Update explore data in the database
      await axios.put(`${API_URL}/exploreData`, exploreData);
      
      // Update user's explore stats
      const userResponse = await axios.get(`${API_URL}/users?username=${answer.author}`);
      if (userResponse.data.length > 0) {
        const user = userResponse.data[0];
        const updatedUser = {
          ...user,
          exploreAnswers: user.exploreAnswers + 1
        };
        
        await axios.put(`${API_URL}/users/${user.id}`, updatedUser);
      }
    }
  }
};

// Vote for an answer in explore mode
export const voteExploreAnswer = async (
  gradeSubject: string,
  topicId: string,
  answerId: string,
  userId: string,
  questionIndex: number
): Promise<void> => {
  // First, get current explore data
  const exploreDataResponse = await axios.get(`${API_URL}/exploreData`);
  const exploreData = exploreDataResponse.data;

  // Find the topic and the answer
  const topicsByGradeSubject = exploreData.topicsByGradeSubject;
  
  if (topicsByGradeSubject[gradeSubject]) {
    const topicIndex = topicsByGradeSubject[gradeSubject].findIndex(
      (topic: any) => String(topic.id) === topicId
    );
    
    if (topicIndex !== -1) {
      const topic = topicsByGradeSubject[gradeSubject][topicIndex];
      
      // Check if user has already voted on this question
      if (!topic.question_votes) {
        topic.question_votes = [];
      }
      
      // Check if user has already voted on this specific question (within topic)
      const userVotedOnThisQuestion = topic.question_votes.some(
        ([uid, qIndex, _]: [string, number, string]) => uid === userId && qIndex === questionIndex
      );
      
      if (userVotedOnThisQuestion) {
        throw new Error('You have already voted on this question');
      }
      
      // Add user's vote to the question_votes array
      topic.question_votes.push([userId, questionIndex, answerId]);
      
      const answerIndex = topic.answers.findIndex(
        (answer: any) => String(answer.id) === answerId
      );
      
      if (answerIndex !== -1) {
        // Increment the answer's vote count
        topic.answers[answerIndex].votes += 1;
        
        // Update explore data in the database
        await axios.put(`${API_URL}/exploreData`, exploreData);
        
        // Update the answer author's explore stats
        const authorUsername = topic.answers[answerIndex].author;
        const authorResponse = await axios.get(`${API_URL}/users?username=${authorUsername}`);
        
        if (authorResponse.data.length > 0) {
          const author = authorResponse.data[0];
          const updatedAuthor = {
            ...author,
            exploreVotes: author.exploreVotes + 1
          };
          
          await axios.put(`${API_URL}/users/${author.id}`, updatedAuthor);
        }
        
        // Update the voter's explore stats
        const voterResponse = await axios.get(`${API_URL}/users?username=${userId}`);
        
        if (voterResponse.data.length > 0) {
          const voter = voterResponse.data[0];
          const updatedVoter = {
            ...voter,
            exploreScore: voter.exploreScore + 1
          };
          
          await axios.put(`${API_URL}/users/${voter.id}`, updatedVoter);
        }
      }
    }
  }
};

// Update an answer in explore mode
export const updateExploreAnswer = async (
  gradeSubject: string,
  topicId: string,
  answerId: string,
  newBody: string
): Promise<void> => {
  // First, get current explore data
  const exploreDataResponse = await axios.get(`${API_URL}/exploreData`);
  const exploreData = exploreDataResponse.data;

  // Find the topic and the answer
  const topicsByGradeSubject = exploreData.topicsByGradeSubject;
  
  if (topicsByGradeSubject[gradeSubject]) {
    const topicIndex = topicsByGradeSubject[gradeSubject].findIndex(
      (topic: any) => String(topic.id) === topicId
    );
    
    if (topicIndex !== -1) {
      const topic = topicsByGradeSubject[gradeSubject][topicIndex];
      const answerIndex = topic.answers.findIndex(
        (answer: any) => String(answer.id) === answerId
      );
      
      if (answerIndex !== -1) {
        // Update the answer body
        topic.answers[answerIndex].body = newBody;
        
        // Update explore data in the database
        await axios.put(`${API_URL}/exploreData`, exploreData);
      }
    }
  }
};

// Delete an answer in explore mode
export const deleteExploreAnswer = async (
  gradeSubject: string,
  topicId: string,
  answerId: string
): Promise<void> => {
  // First, get current explore data
  const exploreDataResponse = await axios.get(`${API_URL}/exploreData`);
  const exploreData = exploreDataResponse.data;

  // Find the topic and remove the answer
  const topicsByGradeSubject = exploreData.topicsByGradeSubject;
  
  if (topicsByGradeSubject[gradeSubject]) {
    const topicIndex = topicsByGradeSubject[gradeSubject].findIndex(
      (topic: any) => String(topic.id) === topicId
    );
    
    if (topicIndex !== -1) {
      const topic = topicsByGradeSubject[gradeSubject][topicIndex];
      
      // Remove answer from answers array
      topic.answers = topic.answers.filter(
        (answer: any) => String(answer.id) !== answerId
      );
      
      // Remove any votes for this answer
      if (topic.question_votes) {
        topic.question_votes = topic.question_votes.filter(
          ([_, __, aid]: [string, number, string]) => aid !== answerId
        );
      }
      
      // Update explore data in the database
      await axios.put(`${API_URL}/exploreData`, exploreData);
    }
  }
};

// Voting functionality
export const saveVote = async (userId: number, questionId: number, answerId: number): Promise<void> => {
  // First get the user
  const userResponse = await axios.get(`${API_URL}/users/${userId}`);
  const user = userResponse.data;
  
  // Update user question_vote
  const questionVote: [number, number] = [questionId, answerId];
  const updatedUser = {
    ...user,
    question_vote: [...(user.question_vote || []), questionVote],
  };
  
  // Save updated user
  await axios.put(`${API_URL}/users/${userId}`, updatedUser);
  
  // Update the answer votes
  const answerResponse = await axios.get(`${API_URL}/answers/${answerId}`);
  const answer = answerResponse.data;
  
  const updatedAnswer = {
    ...answer,
    votes: answer.votes + 1
  };
  
  await axios.put(`${API_URL}/answers/${answerId}`, updatedAnswer);
}; 