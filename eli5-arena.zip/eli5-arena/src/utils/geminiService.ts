import { GoogleGenerativeAI, BlockReason } from "@google/generative-ai";

// TODO: Replace with your actual API key
const API_KEY = "YOUR API KEY HERE";

// Check if API_KEY is set (basic check)
if (!API_KEY) {
  console.warn(
    "Gemini API key is not set. Please replace 'YOUR_API_KEY_HERE' in src/utils/geminiService.ts with your actual key."
  );
}

let genAI: GoogleGenerativeAI | null = null;
let model: any = null; // Using any for model type flexibility

if (API_KEY) {
  try {
    genAI = new GoogleGenerativeAI(API_KEY);
    model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
  } catch (error) {
    console.error("Failed to initialize GoogleGenerativeAI:", error);
    genAI = null;
    model = null;
  }
}

/**
 * Asks the Gemini model to explain a given question like the user is five years old.
 * @param questionTitle The title of the question.
 * @param questionBody The body/content of the question.
 * @returns A promise that resolves with the ELI5 explanation string, or null if an error occurs or the API key/model is missing.
 */
export const explainLikeImFive = async (
  questionTitle: string,
  questionBody: string
): Promise<string | null> => {
  // Don't proceed if the API key is missing or model initialization failed
  if (!model) {
    console.error("Gemini model not initialized. Check API key and initialization.");
    return null;
  }

  const prompt = `Explain this question like I'm five years old:\n\nTitle: ${questionTitle}\n\nQuestion: ${questionBody}`;
  console.log("Sending prompt to Gemini:", prompt); // Log the prompt for debugging

  try {
    const result = await model.generateContent(prompt);
    const response = result.response;
    
    // Check for safety blocks before accessing text
    if (response.promptFeedback?.blockReason) {
      console.error(
        "Request blocked due to safety settings:",
        response.promptFeedback.blockReason
      );
      const blockMessage = `Sorry, the request was blocked due to: ${response.promptFeedback.blockReason}.`;
      if (response.promptFeedback.blockReason === BlockReason.SAFETY && response.promptFeedback.safetyRatings) {
        console.error("Safety Ratings:", response.promptFeedback.safetyRatings);
      }
      return blockMessage;
    }
    
    const explanation = response.text();
    return explanation;
  } catch (error: any) { // Catching as any to inspect potential properties
    console.error("Error calling Gemini API:", error);
    
    // Attempt to check for block reason even within the catch block if available
    if (error?.response?.promptFeedback?.blockReason) {
       console.error(
        "Request blocked due to safety settings (in catch block):",
        error.response.promptFeedback.blockReason
      );
       return `Sorry, the request was blocked due to: ${error.response.promptFeedback.blockReason}.`;
    }
    
    return "An error occurred while trying to get an explanation."; // More generic error for other issues
  }
}; 